// Set the AWS Region.
exports.REGION = "us-west-2"; //e.g. "us-east-1"
exports.BUCKET = "s3://build-manager-artifacts-bucket/"
