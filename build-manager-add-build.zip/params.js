// Set the AWS Region.
exports.REGION = "us-west-2"; //e.g. "us-east-1"
var BUCKET_NAME = "build-manager-artifacts-bucket"
exports = BUCKET_NAME
exports.BUCKET_URL= "s3://" + BUCKET_NAME + "/"
